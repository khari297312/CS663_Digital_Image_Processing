% Load images
barbara = imread ( ’ C :\ Users \ Admin \ OneDrive - Indian Institute of
Technology Bombay \ CS663 \ HW3 \ barbara256 . png ’) ;
kodak = imread ( ’ C :\ Users \ Admin \ OneDrive - Indian Institute of
Technology Bombay \ CS663 \ HW3 \ kodak24 . png ’) ;
% Convert to grayscale if needed
if size ( barbara , 3) == 3
barbara = rgb2gray ( barbara ) ;
end
if size ( kodak , 3) == 3
kodak = rgb2gray ( kodak ) ;
end
% Add Gaussian noise ( = 5)
sigma_noise = 5;
noisy_barbara = imnoise ( double ( barbara ) / 255 , ’ gaussian ’ , 0 , (
sigma_noise /255) ^2) * 255;
noisy_kodak = imnoise ( double ( kodak ) / 255 , ’ gaussian ’ , 0 , ( sigma_noise
/255) ^2) * 255;
% Save and display noisy images
imwrite ( uint8 ( noisy_barbara ) , ’ noisy_barbara_sigma5 . png ’) ;
imwrite ( uint8 ( noisy_kodak ) , ’ noisy_kodak_sigma5 . png ’) ;
figure ;
subplot (1 , 2 , 1) ; imshow ( uint8 ( noisy_barbara ) ) ; title ( ’ Noisy Barbara
=5 ’) ; drawnow ;
subplot (1 , 2 , 2) ; imshow ( uint8 ( noisy_kodak ) ) ; title ( ’ Noisy Kodak =5 ’)
; drawnow ;
% Mean shift filtering function
function filtered_img = meanShiftFilter ( img , spatial_bw , range_bw )
img = double ( img ) ;
half_window_size = round ( spatial_bw * 3) ; % Define the window size
based on spatial bandwidth
[ rows , cols ] = size ( img ) ;
filtered_img = zeros ( size ( img ) ) ;
for r = 1: rows
for c = 1: cols
x = r ;
y = c ;
z = img (r , c ) ; % Get intensity
% Iterative process of mean shift
for iter = 1:10 % Maximum number of iterations
% Create a window around the current point
rmin = max (1 , x - half_window_size ) ;
rmax = min ( rows , x + half_window_size ) ;
cmin = max (1 , y - half_window_size ) ;
cmax = min ( cols , y + half_window_size ) ;
1
% Extract the neighborhood region
region = img ( rmin : rmax , cmin : cmax ) ;
% Get the size of the region
[ region_height , region_width ] = size ( region ) ;
% Create meshgrid for spatial weights with the size of
the region
[X , Y ] = meshgrid (1: region_width , 1: region_height ) ;
% Calculate the spatial weights
spatial_weights = exp ( -(( X -( round ( region_width /2) ) ) .^2
+ (Y -( round ( region_height /2) ) ) .^2) / (2* spatial_bw
^2) ) ;
% Calculate the range weights based on the region ’ s
pixel intensities
range_weights = exp ( -(( region - z ) .^2) / (2* range_bw ^2)
) ;
% Combine the spatial and range weights
weights = spatial_weights .* range_weights ;
% Weighted mean shift in the spatial and range space
weighted_region = weights .* region ;
sum_weights = sum ( weights (:) ) ;
% Compute the new intensity ( z ) value
new_z = sum ( weighted_region (:) ) / sum_weights ;
% Check for convergence
if abs ( new_z - z ) < 0.1
break ;
end
% Update intensity
z = new_z ;
end
% Set the pixel value after mean shift convergence
filtered_img (r , c ) = z ;
end
end
% Clip to valid range and return
filtered_img = uint8 ( min ( max ( filtered_img , 0) , 255) ) ;
end
% Apply mean shift filter with different parameters for = 5
filtered_barbara_1 = meanShiftFilter ( noisy_barbara , 2 , 2) ;
filtered_barbara_2 = meanShiftFilter ( noisy_barbara , 15 , 3) ;
filtered_barbara_3 = meanShiftFilter ( noisy_barbara , 3 , 15) ;
filtered_kodak_1 = meanShiftFilter ( noisy_kodak , 2 , 2) ;
filtered_kodak_2 = meanShiftFilter ( noisy_kodak , 15 , 3) ;
filtered_kodak_3 = meanShiftFilter ( noisy_kodak , 3 , 15) ;
2
% Save and display filtered images for = 5
imwrite ( uint8 ( filtered_barbara_1 ) , ’ filtered_barbara_sigma5_s2_r2 . png ’)
;
imwrite ( uint8 ( filtered_barbara_2 ) , ’ filtered_barbara_sigma5_s15_r3 . png
’) ;
imwrite ( uint8 ( filtered_barbara_3 ) , ’ filtered_barbara_sigma5_s3_r15 . png
’) ;
imwrite ( uint8 ( filtered_kodak_1 ) , ’ filtered_kodak_sigma5_s2_r2 . png ’) ;
imwrite ( uint8 ( filtered_kodak_2 ) , ’ filtered_kodak_sigma5_s15_r3 . png ’) ;
imwrite ( uint8 ( filtered_kodak_3 ) , ’ filtered_kodak_sigma5_s3_r15 . png ’) ;
figure ;
subplot (2 , 3 , 1) ; imshow ( uint8 ( filtered_barbara_1 ) ) ; title ( ’ Barbara
Filtered s =2 , r =2 ’) ; drawnow ;
subplot (2 , 3 , 2) ; imshow ( uint8 ( filtered_barbara_2 ) ) ; title ( ’ Barbara
Filtered s =15 , r =3 ’) ; drawnow ;
subplot (2 , 3 , 3) ; imshow ( uint8 ( filtered_barbara_3 ) ) ; title ( ’ Barbara
Filtered s =3 , r =15 ’) ; drawnow ;
subplot (2 , 3 , 4) ; imshow ( uint8 ( filtered_kodak_1 ) ) ; title ( ’ Kodak
Filtered s =2 , r =2 ’) ; drawnow ;
subplot (2 , 3 , 5) ; imshow ( uint8 ( filtered_kodak_2 ) ) ; title ( ’ Kodak
Filtered s =15 , r =3 ’) ; drawnow ;
subplot (2 , 3 , 6) ; imshow ( uint8 ( filtered_kodak_3 ) ) ; title ( ’ Kodak
Filtered s =3 , r =15 ’) ; drawnow ;
% Add Gaussian noise ( = 10)
sigma_noise = 10;
noisy_barbara_10 = imnoise ( double ( barbara ) / 255 , ’ gaussian ’ , 0 , (
sigma_noise /255) ^2) * 255;
noisy_kodak_10 = imnoise ( double ( kodak ) / 255 , ’ gaussian ’ , 0 , (
sigma_noise /255) ^2) * 255;
% Save and display noisy images for = 10
imwrite ( uint8 ( noisy_barbara_10 ) , ’ noisy_barbara_sigma10 . png ’) ;
imwrite ( uint8 ( noisy_kodak_10 ) , ’ noisy_kodak_sigma10 . png ’) ;
figure ;
subplot (1 , 2 , 1) ; imshow ( uint8 ( noisy_barbara_10 ) ) ; title ( ’ Noisy Barbara
=10 ’) ; drawnow ;
subplot (1 , 2 , 2) ; imshow ( uint8 ( noisy_kodak_10 ) ) ; title ( ’ Noisy Kodak
=10 ’) ; drawnow ;
% Apply mean shift filter with different parameters for = 10
filtered_barbara_1_10 = meanShiftFilter ( noisy_barbara_10 , 2 , 2) ;
filtered_barbara_2_10 = meanShiftFilter ( noisy_barbara_10 , 15 , 3) ;
filtered_barbara_3_10 = meanShiftFilter ( noisy_barbara_10 , 3 , 15) ;
filtered_kodak_1_10 = meanShiftFilter ( noisy_kodak_10 , 2 , 2) ;
filtered_kodak_2_10 = meanShiftFilter ( noisy_kodak_10 , 15 , 3) ;
filtered_kodak_3_10 = meanShiftFilter ( noisy_kodak_10 , 3 , 15) ;
% Save and display filtered images for = 10
imwrite ( uint8 ( filtered_barbara_1_10 ) , ’ filtered_barbara_sigma10_s2_r2 .
png ’) ;
imwrite ( uint8 ( filtered_barbara_2_10 ) , ’ filtered_barbara_sigma10_s15_r3 .
png ’) ;
3
imwrite ( uint8 ( filtered_barbara_3_10 ) , ’ filtered_barbara_sigma10_s3_r15 .
png ’) ;
imwrite ( uint8 ( filtered_kodak_1_10 ) , ’ filtered_kodak_sigma10_s2_r2 . png ’)
;
imwrite ( uint8 ( filtered_kodak_2_10 ) , ’ filtered_kodak_sigma10_s15_r3 . png
’) ;
imwrite ( uint8 ( filtered_kodak_3_10 ) , ’ filtered_kodak_sigma10_s3_r15 . png
’) ;
figure ;
subplot (2 , 3 , 1) ; imshow ( uint8 ( filtered_barbara_1_10 ) ) ; title ( ’ Barbara
Filtered s =2 , r =2 ’) ; drawnow ;
subplot (2 , 3 , 2) ; imshow ( uint8 ( filtered_barbara_2_10 ) ) ; title ( ’ Barbara
Filtered s =15 , r =3 ’) ; drawnow ;
subplot (2 , 3 , 3) ; imshow ( uint8 ( filtered_barbara_3_10 ) ) ; title ( ’ Barbara
Filtered s =3 , r =15 ’) ; drawnow ;
subplot (2 , 3 , 4) ; imshow ( uint8 ( filtered_kodak_1_10 ) ) ; title ( ’ Kodak
Filtered s =2 , r =2 ’) ; drawnow ;
subplot (2 , 3 , 5) ; imshow ( uint8 ( filtered_kodak_2_10 ) ) ; title ( ’ Kodak
Filtered s =15 , r =3 ’) ; drawnow ;
subplot (2 , 3 , 6) ; imshow ( uint8 ( filtered_kodak_3_10 ) ) ; title ( ’ Kodak
Filtered s =3 , r =15 ’) ; drawnow ;
