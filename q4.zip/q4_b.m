% Parameters
num_people = 38;      % Total number of people (excluding person 14)
max_training = 40;    % Maximum number of training images per person
max_testing = 24;     % Maximum number of testing images per person
img_rows = 192;       % Number of rows in the images
img_cols = 168;       % Number of columns in the images
img_size = img_rows * img_cols;

% Initialize matrices
train_set = [];
test_set = [];
train_labels = [];
test_labels = [];

% Read images
for person = 1:num_people
    if person == 14
        continue;  % Skip folder 14 as mentioned
    end
    
    folder = sprintf('/MATLAB Drive/cs663_hw4/CroppedYale/yaleB%02d', person);
    files = dir(fullfile(folder, '*.pgm'));
    total_images = length(files);
    
    % Display how many images are available for each person
    fprintf('Person %d has %d images.\n', person, total_images);
    
    % Check if there are enough images for training and testing
    if total_images < (max_training + max_testing)
        % Adjust the number of training and testing images based on available images
        num_training = floor(total_images * 0.66); % 62.5% for training
        num_testing = total_images - num_training;  % Remaining for testing
        if num_training < 1 || num_testing < 1
            warning('Person %d does not have enough images for training/testing. Skipping this person.', person);
            continue; % Skip if not enough images for either set
        end
    else
        num_training = max_training; % Use the predefined values
        num_testing = max_testing;    % Use the predefined values
    end
    
    % Read training images (first num_training)
    for i = 1:num_training
        img = imread(fullfile(folder, files(i).name));
        train_set = [train_set reshape(img, [], 1)];  % Add flattened image
        train_labels = [train_labels person];
    end
    
    % Read testing images (next num_testing)
    for i = (num_training + 1):(num_training + num_testing)
        img = imread(fullfile(folder, files(i).name));
        test_set = [test_set reshape(img, [], 1)];
        test_labels = [test_labels person];
    end
end

% Check if we have enough training and testing data
if isempty(train_set) || isempty(test_set)
    error('Not enough training or testing data available. Check the dataset.');
end

% Convert to double and normalize
train_set = double(train_set);
test_set = double(test_set);
mean_face = mean(train_set, 2); % Compute mean face
train_set = train_set - mean_face; % Mean-centering
test_set = test_set - mean_face;

% Calculate covariance matrix and eigenvectors
cov_matrix = train_set' * train_set;
[V, D] = eig(cov_matrix);

% Sort eigenvalues and eigenvectors
[eigenvalues, idx] = sort(diag(D), 'descend');
V = V(:, idx);

% Project data onto eigenvectors (eigenfaces)
eigen_faces = train_set * V;
eigen_faces = bsxfun(@rdivide, eigen_faces, sqrt(sum(eigen_faces.^2, 1))); % Normalize

% Recognition rates for k values
k_values = [1, 2, 3, 5, 10, 15, 20, 30, 50, 60, 65, 75, 100, 200, 300, 500, 1000];
recognition_rates_all = zeros(size(k_values));
recognition_rates_reduced = zeros(size(k_values));

for k_idx = 1:length(k_values)
    k = k_values(k_idx);
    
    % Ensure k does not exceed the number of eigenfaces
    num_eigenfaces = size(eigen_faces, 2);
    if k > num_eigenfaces
        warning('k = %d exceeds available eigenfaces. Skipping.', k);
        recognition_rates_all(k_idx) = NaN;
        recognition_rates_reduced(k_idx) = NaN;
        continue;
    end

    % Project training and test data onto top k eigenfaces
    train_projected = eigen_faces(:, end-k+1:end)' * train_set;
    test_projected = eigen_faces(:, end-k+1:end)' * test_set;
    
    % Classification based on minimum squared difference (using all coefficients)
    correct_count_all = 0;
    for i = 1:size(test_set, 2)
        differences_all = sum((train_projected - test_projected(:, i)).^2, 1);
        [~, closest_idx] = min(differences_all);
        if train_labels(closest_idx) == test_labels(i)
            correct_count_all = correct_count_all + 1;
        end
    end
    recognition_rates_all(k_idx) = correct_count_all / size(test_set, 2);
    
    % Classification excluding the three largest eigencoefficients
    if k > 3
        reduced_train_projected = eigen_faces(:, end-k+1:end-3)' * train_set;
        reduced_test_projected = eigen_faces(:, end-k+1:end-3)' * test_set;
        
        correct_count_reduced = 0;
        for i = 1:size(test_set, 2)
            differences_reduced = sum((reduced_train_projected - reduced_test_projected(:, i)).^2, 1);
            [~, closest_idx] = min(differences_reduced);
            if train_labels(closest_idx) == test_labels(i)
                correct_count_reduced = correct_count_reduced + 1;
            end
        end
        recognition_rates_reduced(k_idx) = correct_count_reduced / size(test_set, 2);
    else
        recognition_rates_reduced(k_idx) = NaN; % Not applicable for k <= 3
    end
end

% Plot recognition rates
figure;
plot(k_values, recognition_rates_all, '-o', 'DisplayName', 'All Eigencoefficients');
hold on;
plot(k_values, recognition_rates_reduced, '-s', 'DisplayName', 'Excluding 3 Largest');
xlabel('Number of Principal Components (k)');
ylabel('Recognition Rate');
title('Recognition Rate vs Number of Principal Components');
legend('show');
grid on;

% Face reconstruction
k_recon_values = [2, 10, 20, 50, 75, 100, 125, 150, 175];
if size(train_set, 2) > 0
    original_face = train_set(:, 1);  % Choose a face to reconstruct
else
    error('No training images available for reconstruction.');
end

figure;
for i = 1:length(k_recon_values)
    k = k_recon_values(i);
    
    % Reconstruct the face using top k eigenvectors
    weights = eigen_faces(:, end-k+1:end)' * (original_face - mean_face);
    face_reconstructed = mean_face + eigen_faces(:, end-k+1:end) * weights;
    
    subplot(3, 3, i);
    imagesc(reshape(face_reconstructed, [img_rows, img_cols]));
    colormap gray;
    title(['k = ', num2str(k)]);
end

% Plot the 25 eigenvectors (eigenfaces) corresponding to the 25 largest eigenvalues
figure;
for i = 1:min(25, size(eigen_faces, 2)) % Ensure we don't exceed available eigenfaces
    eigenface = eigen_faces(:, end-i+1);  % Get the i-th largest eigenface
    subplot(5, 5, i);
    imagesc(reshape(eigenface, [img_rows, img_cols]));
    colormap gray;
    title(['Eigenface ', num2str(i)]);
end
