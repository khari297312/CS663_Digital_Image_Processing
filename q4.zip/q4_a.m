% Set the parameters
num_people = 32;  % Number of subjects (folders)
num_training = 6; % First 6 images for training
num_testing = 4;  % Remaining 4 images for testing
img_rows = 92;
img_cols = 110;
img_size = img_rows * img_cols;

% Initialize matrices
train_set = [];
test_set = [];
train_labels = [];
test_labels = [];

% Loop through each person's folder and load the images
for person = 1:num_people
    folder = fullfile('/MATLAB Drive/cs663_hw4/ORL', ['s' num2str(person)]);  % Adjust the path to ORL dataset
    
    % Get the list of PGM files in the folder
    files = dir(fullfile(folder, '*.pgm'));
    
    % Load training images
    for i = 1:num_training
        img = imread(fullfile(folder, files(i).name));
        train_set = [train_set reshape(img, [], 1)];  % Flatten the image and append
        train_labels = [train_labels person];
    end
    
    % Load testing images
    for i = num_training+1:num_training+num_testing
        img = imread(fullfile(folder, files(i).name));
        test_set = [test_set reshape(img, [], 1)];  % Flatten the image and append
        test_labels = [test_labels person];
    end
end

% Convert training and test data to double precision
train_set = double(train_set);
test_set = double(test_set);

% Mean centering the data
mean_face = mean(train_set, 2);  % Compute the mean face
train_set = train_set - mean_face;  % Subtract mean face from training data
test_set = test_set - mean_face;    % Subtract mean face from test data

% Step 1: EIGENFACES METHOD
% Calculate covariance matrix and eigenvectors
cov_matrix = train_set' * train_set;  % Covariance matrix (smaller dimensional)
[V, D] = eig(cov_matrix);  % Eigen-decomposition

% Project training data onto eigenvectors
eigen_faces = train_set * V;  % Compute the actual eigenfaces
eigen_faces = bsxfun(@rdivide, eigen_faces, sqrt(sum(eigen_faces.^2, 1)));  % Normalize eigenfaces

% Test different values of k
k_values = [1, 2, 3, 5, 10, 15, 20, 30, 50, 75, 100, 150, 170];
recognition_rates = zeros(size(k_values));

for k_idx = 1:length(k_values)
    k = k_values(k_idx);
    
    % Project training and testing data onto top k eigenfaces
    train_projected = eigen_faces(:, end-k+1:end)' * train_set;  % Project training set
    test_projected = eigen_faces(:, end-k+1:end)' * test_set;    % Project test set
    
    % Classification based on minimum squared difference
    correct_count = 0;
    for i = 1:size(test_set, 2)
        differences = sum((train_projected - test_projected(:, i)).^2, 1);  % Compute Euclidean distances
        [~, closest_idx] = min(differences);  % Find the closest training image
        if train_labels(closest_idx) == test_labels(i)
            correct_count = correct_count + 1;
        end
    end
    
    recognition_rates(k_idx) = correct_count / size(test_set, 2);
end

% Plot the recognition rate (EIG method)
figure;
plot(k_values, recognition_rates, '-o');
xlabel('Number of Principal Components (k)');
ylabel('Recognition Rate');
title('Recognition Rate vs Number of Principal Components (EIG)');

% Step 2: SVD METHOD
% Perform SVD on the training data matrix
[U, S, V] = svd(train_set, 'econ');  % Reduced SVD

% Test different values of k for SVD method
recognition_rates_svd = zeros(size(k_values));

for k_idx = 1:length(k_values)
    k = k_values(k_idx);
    
    % Project training and testing data onto top k singular vectors
    train_projected_svd = U(:, 1:k)' * train_set;  % Project training set
    test_projected_svd = U(:, 1:k)' * test_set;    % Project test set
    
    % Classification based on minimum squared difference
    correct_count_svd = 0;
    for i = 1:size(test_set, 2)
        differences_svd = sum((train_projected_svd - test_projected_svd(:, i)).^2, 1);  % Compute Euclidean distances
        [~, closest_idx_svd] = min(differences_svd);  % Find the closest training image
        if train_labels(closest_idx_svd) == test_labels(i)
            correct_count_svd = correct_count_svd + 1;
        end
    end
    
    recognition_rates_svd(k_idx) = correct_count_svd / size(test_set, 2);
end

% Plot the recognition rate (SVD method)
figure;
plot(k_values, recognition_rates_svd, '-o');
xlabel('Number of Singular Components (k)');
ylabel('Recognition Rate (SVD)');
title('Recognition Rate vs Number of Singular Components (SVD)');
