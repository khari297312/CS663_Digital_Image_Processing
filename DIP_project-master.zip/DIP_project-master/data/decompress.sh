
for i in {1..5};do zpaq x im$i.archive ;done
for i in {1..5};do jbgtopbm m_im$i.jbg m_im$i.pbm ;done



